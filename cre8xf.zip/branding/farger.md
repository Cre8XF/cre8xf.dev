# CRE8XF Fargeprofil

- Bakgrunn: #000000 (sort)
- Primærglød: #FFD700 (gullgul)
- Sekundærtekst: #ffffff (hvit)
