Dette er et eksempel på en typisk 3–5-siders nettside.

Template: Business Casual  
Kilde: https://startbootstrap.com/theme/business-casual  
Lisens: MIT License – Gratis for personlig og kommersiell bruk med kreditering

Brukes kun som demonstrasjon for kurs eller som eksempel på strukturert nettside.
