Denne nettsiden er kun ment som eksempel på en typisk 3–5-siders nettside.

Basert på: "Business Casual" fra Start Bootstrap  
Lastet ned fra: https://startbootstrap.com/theme/business-casual  
Lisens: MIT License – Gratis for personlig og kommersiell bruk med henvisning

Ingen endringer i funksjon – kun brukt for demonstrasjon i kurs- og presentasjonssammenheng.
