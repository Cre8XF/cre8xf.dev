# Kurs: AI i Arbeidslivet

Innhold og struktur for kurs som lærer bort praktisk bruk av AI på jobb.